WEDISON BALI | Aset color picker untuk IT

1. Ekstrak ZIP dan buka preview.html di browser. Demo berjalan offline.
2. assets/paints/ berisi gambar WebP bodi motor per pilihan warna.
3. colors.json memetakan model, default, ID warna, label Indonesia/English, HEX, finish, dan path gambar. Path relatif terhadap root paket; sesuaikan base URL di aplikasi.
4. Saat pengguna memilih swatch, gunakan HEX untuk tombol dan ganti src gambar motor ke nilai image dari varian terpilih. Tidak perlu filter CSS pada motor.
5. Untuk Victory, black-matte dan black-glossy memiliki HEX yang sama tetapi foto serta finish berbeda. Gunakan ID, bukan HEX, sebagai kunci.
6. reference/ berisi JS dan CSS dari situs untuk referensi integrasi; keduanya mengandalkan struktur halaman Wedison. preview.html adalah contoh mandiri.
7. HEX adalah perkiraan untuk layar, bukan kode cat pabrik atau data stok. Bees Pro dan Tank tidak termasuk karena belum memiliki picker pada katalog ini.
